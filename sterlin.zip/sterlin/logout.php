<?php
    $mac=$_POST['mac'];
    $ip=$_POST['ip'];
    $username=$_POST['username'];
    $linklogin=$_POST['link-login'];
    $linkorig=$_POST['link-orig'];
    $error=$_POST['error'];
    $trial=$_POST['trial'];
    $loginby=$_POST['login-by'];
    $chapid=$_POST['chap-id'];
    $chapchallenge=$_POST['chap-challenge'];
    $linkloginonly=$_POST['link-login-only'];
    $linkorigesc=$_POST['link-orig-esc'];
    $macesc=$_POST['mac-esc'];
    $identity=$_POST['identity'];
    $bytesinnice=$_POST['bytes-in-nice'];
    $bytesoutnice=$_POST['bytes-out-nice'];
    $sessiontimeleft=$_POST['session-time-left'];
    $uptime=$_POST['uptime'];
    $refreshtimeout=$_POST['refresh-timeout'];   
    $linkstatus=$_POST['link-status'];  
?>


<!DOCTYPE html>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sterling Bank</title>
<link rel="stylesheet" type="text/css" href="css/cssstyles.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<style>
    .centered-form{
	margin-top: 60px;
}

.centered-form .panel{
	background: rgba(255, 255, 255, 0.8);
	box-shadow: rgba(0, 0, 0, 0.3) 20px 20px 20px;
}
</style>
<body>
<center>

   <div class="container">
        <div class="row centered-form">
        <div class="col-xs-12 col-sm-8 col-md-4 col-sm-offset-2 col-md-offset-4">
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">You have just logged out.!</small></h3>
			 			</div>
			 			<div class="panel-body">
			    	     <table class="table table-striped">
                            <tbody>
                            <tr>
                                <td>user name</td>
                                <td><?php echo $username; ?></td>
                            </tr>
                            <tr>
                                <td>IP address</td>
                                <td><?php echo $ip; ?></td>
                            </tr>
                            <tr>
                                <td>MAC address</td>
                                <td><?php echo $mac; ?></td>
                            </tr>
                            <tr>
                                <td>session time</td>
                                <td><?php echo $uptime; ?></td>
                            </tr>
                            <?php if($sessiontimeleft) : ?>
                                <tr>
                                    <td>time left</td>
                                    <td><?php echo $sessiontimeleft; ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td>bytes up/down:</td>
                                <td><?php echo $bytesinnice; ?> / <?php echo $bytesoutnice; ?></td>
                            </tr>
                            </tbody>
                        </table>
			    	    
			    	</div>
	    		</div>
    		</div>
    	</div>
    </div>

</center>

<script src="jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

</body>
</html>
